<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
class DepartmentController extends Controller
{
    public function save_department(Request $request)
    {
        Log::info('Inside save_deparment');
        $v = Validator::make($request->all(), [
            'department_name'=>'string|required',
            'short_name'=>'string|required',
            'address'=>'string|required',
            'geolocation'=>'array|required',
            'landmark'=>'string|required'
            
        ]);
        if ($v->fails())
        {
           return $v->errors();
        }
       try{ 
          
            $department_name=$request->department_name;
            $short_name=$request->short_name;
            $address=$request->address;
            $geolocation=$request->geolocation;
            $landmark=$request->landmark;   
            Log::info('Inside save_deparment');        
            $insert=DB::table('dept_address')->insert([
                'department_name'=>$department_name,
                'short_name'=>$short_name,
                'address'=>$address,
                'geolocation'=>json_encode($geolocation),
                'landmark'=>$landmark
            ]);
            if($insert)
            {
                return response()->json(['status'=>'success','mag'=>'Data inserted successfully']);
            }
            else
            {
                return response()->json(['status'=>'error','mag'=>'Data can`t be inserted']);
            }
            
       } catch (QueryException $e) {
            Log::error("Database error ! [" . $e->getMessage() . "]");
            return response()->json(array('status' => 'error', 'msg' => 'Database error'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return response()->json(array('status' => 'error', 'msg' => 'Error'));
        }
    }
    public function get_department(Request $request)
    {
        
       try{ 
                $data=DB::table('dept_address')->get();
                return response()->json(['status'=>'success','data'=>$data]);
               
        }catch(QueryException $e){
            Log::error($e->getMessage());
            return response()->json(['status'=>'failed','msg'=> 'Something Went Wrong',], 500);
        }
    }
}
