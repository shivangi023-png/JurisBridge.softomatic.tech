var mentionedStaffIds = [];
fetch_hearing_task();
$(".task_comment").on("keyup", function (e) {
  $.ajaxSetup({
    headers: {
      "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
    },
  });
  var content = $(this).html();
  var matches = content.match(/@([^\s@]+)$/);
  if (matches) {
    // Fetch suggestions
    var searchTerm = matches[1];
    var offset = $(this).offset();
    var topOffset = offset.top - $("#suggestionPopup").outerHeight() - 10;
    var leftOffset = offset.left;
    console.log(searchTerm);
    $.ajax({
      url: "get_mention_assignee",
      type: "POST",
      data: { searchTerm: searchTerm },
      success: function (response) {
        $("#suggestionPopup").html(response).show();
      },
    });
  } else {
    $("#suggestionPopup").hide();
  }
});
$(document).on("click", "#suggestionPopup li", function () {
  var username = $(this).text();
  var id = $(this).attr("id");
  var tgid = $("#tagid").text();
  if (tgid != "") {
    var tag_id = [tgid];
  } else {
    var tag_id = [];
  }
  var content = $(".task_comment").html();
  var matches = content.match(/@([^\s@]+)$/);
  if (matches) {
    var beforeText = content.substring(0, content.length - matches[0].length);
    var newText =
      beforeText +
      '<span class="mentioned" data-id="' +
      id +
      '">@' +
      username +
      "</span>,";
    $(".task_comment").html(newText).focus();

    $("#suggestionPopup").hide();

    // Save mentioned staff ID
    var userId = id;
    mentionedStaffIds.push(userId);
  }
});

$("#project_id,#task_id").val("");
$(".staff_id").select2({
  dropdownAutoWidth: true,
  width: "100%",
  multiple: true,
  placeholder: "Select Staff",
});
$(".project_select").select2({
  dropdownAutoWidth: true,
  width: "100%",
  placeholder: "Select Project",
});
$("#NewProjectModal").on("shown.bs.modal", function (e) {
  $(".staff_id").select2({
    placeholder: "Assignee",
  });
});

// Task functions
$(document).on("click", "#save_task_submit_btn", function () {
  $(".valid_err").html("");
  if ($("#project_id").val() == "") {
    var project_id = $(".project_select").val();
  } else {
    var project_id = $("#project_id").val();
  }
  mentionedStaffIds = [];
  var template_id = $("#template_id").val();
  var task_title = $(".task_title").val();
  var task_description = $(".new_task_editor > .ql-editor").html();
  var task_type = $(".task_type").val();
  var task_priority = $(".task_priority").val();
  var task_assignee = $(".task_assignee").val();
  var task_start_date = $(".task_start_date").val();
  var task_end_date = $(".task_end_date").val();
  var task_status = $(".task_status").val();
  var office_id = $(".office_id").val();
  var working_hr = $(".working_hr").val();
  var task_is_milestone = $(".task_is_milestone:checked").val();
  var task_file = $(".task_file")[0].files[0];
  $(".mentioned").each(function (index) {
    mentionedStaffIds.push($(this).data("id"));
  });

  var comments = $(".task_comment").text();
  console.log("comments=" + comments);

  if (task_is_milestone == undefined) {
    task_is_milestone = "";
  }
  if (task_description == "<p><br></p>") {
    task_description = "";
  }
  var fd = new FormData();
  fd.append("project_id", project_id);
  fd.append("template_id", template_id);
  fd.append("title", task_title);
  fd.append("description", task_description);
  fd.append("type", task_type);
  fd.append("priority", task_priority);
  fd.append("assignee", task_assignee);
  fd.append("task_start_date", task_start_date);
  fd.append("task_end_date", task_end_date);
  fd.append("status", task_status);
  fd.append("is_milestone", task_is_milestone);
  fd.append("file", task_file);
  fd.append("comment", comments);
  fd.append("office_id", office_id);
  fd.append("working_hr", working_hr);
  fd.append("tag_staff_id", mentionedStaffIds);
  var arr = [];
  if (task_title == "") {
    arr.push("task_title_err");
    arr.push("Title required");
  }
  if (project_id == "") {
    arr.push("project_err");
    arr.push("Project required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "add_task",
      data: fd,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        console.log(result);
        var res = result;
        console.log("comment=" + comments);
        console.log("tag=" + mentionedStaffIds);
        console.log(res);
        if (res.status == "success") {
          $(".tbl_div").empty().html(res.body);
          $(".todo-new-task-sidebar,.app-content-overlay").removeClass("show");
          $("#project_id").val("");
          $("#template_id").val("");
          $("#task_id").val("");
          $(".task_title").val("");
          $(".new_task_editor > .ql-editor").html("");
          $(".task_type").val("");
          $(".task_priority").val("");
          $(".task_assignee").val("");
          $(".task_start_date").val("");
          $(".task_end_date").val("");
          $(".task_status").val();
          $(".task_is_milestone").prop("checked", false);

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>'+res.msg+'</span></div></div>'
          );
          fetch_task_list();
          fetch_staff_wise_task_list();
          if (comments != "") {
            $.ajaxSetup({
              headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
              },
            });
            $.ajax({
              type: "post",
              url: "save_task_comment",
              data: {
                task_id: res.task_id,
                tag_staff_id: mentionedStaffIds,
                comment: comments,
                request_from: "web",
                staff_id: res.staff_id,
              },
              success: function (comment_data) {
                console.log(comment_data);
              },
              error: function (comment_data) {
                console.log(comment_data);
              },
            });
          }
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>'+res.msg+'</span></div></div>'
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

//Save Task Template
$(document).on("click", "#submit_task_template_btn", function () {
  $(".valid_err").html("");
  var template_id = $("#template_id").val();
  var task_title = $(".task_title").val();
  var task_description = $(".ql-editor").html();
  var task_type = $(".task_type").val();
  var task_priority = $(".task_priority").val();
  var task_assignee = $(".task_assignee").val();
  var task_start_date = $(".task_start_date").val();
  var task_end_date = $(".task_end_date").val();
  var task_status = $(".task_status").val();
  var task_is_milestone = $(".task_is_milestone:checked").val();
  var task_file = $(".task_file")[0].files[0];

  if (task_is_milestone == undefined) {
    task_is_milestone = "";
  }
  if (task_description == "<p><br></p>") {
    task_description = "";
  }
  var fd = new FormData();
  fd.append("project_id", project_id);
  fd.append("template_id", template_id);
  fd.append("title", task_title);
  fd.append("description", task_description);
  fd.append("type", task_type);
  fd.append("priority", task_priority);
  fd.append("assignee", task_assignee);
  fd.append("task_start_date", task_start_date);
  fd.append("task_end_date", task_end_date);
  fd.append("status", task_status);
  fd.append("is_milestone", task_is_milestone);
  fd.append("file", task_file);

  var arr = [];
  if (task_title == "") {
    arr.push("task_title_err");
    arr.push("Title required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "add_task_template",
      data: fd,

      success: function (data) {
        console.log(data);
        var res = JSON.parse(data);
        console.log(res);
        if (res.status == "success") {
          $(".todo-new-task-sidebar,.app-content-overlay").removeClass("show");
          $("#project_id").val("");
          $("#template_id").val("");
          $("#task_id").val("");
          $(".task_title").val("");
          $(".ql-editor").html("");
          $(".task_type").val("");
          $(".task_priority").val("");
          $(".task_assignee").val("");
          $(".task_date").val("");
          $(".task_status").val();
          $(".task_is_milestone").prop("checked", false);

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          location.reload();
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", "#update_task_btn", function () {
  $(".valid_err").html("");
  var id = $("#task_id").val();
  var project_id = $("#project_id").val();
  var template_id = $("#template_id").val();
  var task_title = $(".task_title").val();
  var task_description = $(".new_task_editor > .ql-editor").html();
  var task_type = $(".task_type").val();
  var task_priority = $(".task_priority").val();
  var task_assignee = $(".task_assignee").val();
  var task_start_date = $(".task_start_date").val();
  var task_end_date = $(".task_end_date").val();
  var task_status = $(".task_status").val();
  var office_id = $(".office_id").val();
  var working_hr = $(".working_hr").val();
  var task_is_milestone = $(".task_is_milestone:checked").val();
  var file_link = $("#file_link").val();
  var task_file = $(".task_file")[0].files[0];
  var task_filter_status = $(".task_filter_status").val();
  var hearing_filter_from_date = $(".hearing_filter_from_date").val();
  var hearing_filter_to_date = $(".hearing_filter_to_date").val();

  if (task_is_milestone == undefined) {
    task_is_milestone = "";
  }
  if (task_file == undefined) {
    task_file = "";
  }
  if (task_description == "<p><br></p>") {
    task_description = "";
  }
  var mentionedUpdateStaffIds = [];
  $(".mentioned").each(function (index) {
    mentionedUpdateStaffIds.push($(this).data("id"));
  });
  var comments_updateTime = $(".task_comment").text();
  // console.log('mentionedUpdateStaffIds');
  // console.log(mentionedUpdateStaffIds);
  // console.log('comments='+comments_updateTime);
  var arr = [];
  if (task_title == "") {
    arr.push("task_title_err");
    arr.push("Title required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    var fd = new FormData();
    fd.append("id", id);
    fd.append("project_id", project_id);
    fd.append("template_id", template_id);
    fd.append("title", task_title);
    fd.append("description", task_description);
    fd.append("type", task_type);
    fd.append("priority", task_priority);
    fd.append("assignee", task_assignee);
    fd.append("task_start_date", task_start_date);
    fd.append("task_end_date", task_end_date);
    fd.append("status", task_status);
    fd.append("office_id", office_id);
    fd.append("working_hr", working_hr);
    fd.append("is_milestone", task_is_milestone);
    fd.append("file", task_file);
    fd.append("file_link", file_link);
    $.ajax({
      type: "post",
      url: "update_task",
      data: fd,
      contentType: false,
      cache: false,
      processData: false,
      success: function (res) {
        if (res.status == "success") {
          $(".todo-new-task-sidebar,.app-content-overlay").removeClass("show");
          $("#project_id").val("");
          $("#template_id").val("");
          $("#task_id").val("");
          $(".task_title").val("");
          $(".new_task_editor > .ql-editor").html("");
          $(".task_type").val("");
          $(".task_priority").val("");
          $(".task_assignee").val("");
          $(".task_start_date").val("");
          $(".task_end_date").val("");
          $(".task_status").val();
          $(".task_is_milestone").prop("checked", false);
          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          fetch_task_list();
          fetch_staff_wise_task_list();
          get_inbox();
          get_outbox();
          fetch_hearing_task(
            hearing_filter_from_date,
            hearing_filter_to_date,
            task_filter_status
          );

          if (comments_updateTime != "") {
            $.ajaxSetup({
              headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
              },
            });
            $.ajax({
              type: "post",
              url: "save_task_comment",
              data: {
                task_id: id,
                tag_staff_id: mentionedUpdateStaffIds,
                comment: comments_updateTime,
                request_from: "web",
                staff_id: res.staff_id,
              },
              success: function (comment_data) {
                console.log(comment_data);
              },
              error: function (comment_data) {
                console.log(comment_data);
              },
            });
          }
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".new_task_btn", function () {
  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });
  $(".div_file_link").hide();

  $("#project_id").val($(this).data("project_id"));
  $("#template_id").val($(this).data("template_id"));
  $("#task_id").val("");
  $(".valid_err").html("");
  $(".task_btn").removeAttr("id");
  $(".new-task-title").empty().html("New Task");
  $(".task_btn").attr("id", "save_task_submit_btn");
  $(".task_btn_name").empty().html("Save");

  console.log('project new task');
  $(".task_title").val("");
  $(".new_task_editor > .ql-editor").html("");
  $(".task_type").val("");
  $(".task_priority").val("");
  $(".task_start_date").val("");
  $(".task_end_date").val("");
  $(".task_status").val(1);
  $(".task_is_milestone").prop("checked", false);

  $(".task_assignee").val("").select2({
    dropdownAutoWidth: true,
    width: "100%",
    placeholder: "Select Assignee",
  }).trigger("change");
  $(".office_id")
    .val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Select Office'
    }).trigger("change");
    $(".working_hr").val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Working Hour'
    }).trigger("change");
  $(".select_proj_id_div").css("display", "none");
  $("#task_comment_div").css("display", "block");
  $(".input_proj_id_div").css("display", "block");
  $(".new_task_modal12,.app-content-overlay").addClass("show");
});
$(document).on("click", ".common_add_task_btn", function () {
  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });
  $(".div_file_link").hide();

  $(".office_id")
    .val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Select Office'
    })
    .trigger("change");
    $(".working_hr")
    .val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Working Hour'
    })
    .trigger("change");
  $("#project_id").val("");
  $("#template_id").val($(this).data("template_id"));
  $("#task_id").val("");
  $(".valid_err").html("");
  $(".task_btn").removeAttr("id");
  $(".new-task-title").empty().html("New Task");
  $(".task_btn").attr("id", "save_task_submit_btn");
  $(".task_btn_name").empty().html("Save");

  $("#save_task_submit_btn").attr('disabled',false);

  $(".task_assignee").select2({
    dropdownAutoWidth: true,
    width: "100%",
    placeholder: "Select Assignee",
  });
  $(".select_proj_id_div").css("display", "block");
  $(".input_proj_id_div").css("display", "none");
  $("#task_comment_div").css("display", "block");
  $(".new_task_modal12,.app-content-overlay").addClass("show");
});

//delete task
$(document).on("click", ".delete_task", function (e) {
  e.preventDefault();
  var delete_task_id = $(this).data("task_id");
  Swal.fire({
    title: "Are you sure?",
    text: "You want to delete this task?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    confirmButtonClass: "btn btn-warning",
    cancelButtonClass: "btn btn-danger ml-1",
    buttonsStyling: false,
  }).then(function (result) {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "delete_task",
        data: {
          id: delete_task_id,
        },
        success: function (res) {
          if (res.status == "success") {
            console.log(delete_task_id);
            $("#subtask-list-" + delete_task_id).remove();
            $(".project_task_tr_" + delete_task_id).remove();
            $("#alert")
              .empty()
              .html(
                '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                  res.msg +
                  "</span></div></div>"
              );
          } else if (res.status == "error") {
            $("#alert")
              .empty()
              .html(
                '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                  res.msg +
                  "</span></div></div>"
              );
          }
        },
        error: function (data) {
          console.log(data);
        },
      });
    }
  });

  if ($(e.target).hasClass("ignore-click") || $("a").hasClass("ignore-click")) {
    return false;
  }
});
//End Task functions

//Project functions
$(document).on("click", "#submit_project_btn", function () {
  $(".valid_err").html("");
  var project_name = $(".project_name").val();
  var project_start_date = $(".project_start_date").val();
  var project_end_date = $(".project_end_date").val();
  var staff_id = $(".staff_id").val();
  var service_id = $(".service_id").val();
  var client_id = $("#client_id").val();
  var case_no = $("#case_no").val();
  var quotation_id = $("#proj_quotation_id").val();
  var project_status = $("#project_status").val();
  if (staff_id.length == 0) {
    staff_id = null;
  }
  var arr = [];
  if (project_name == "") {
    arr.push("project_name_err");
    arr.push("Project Name required");
  }
  if (project_start_date == "") {
    arr.push("project_start_date_err");
    arr.push("Project Start Date Required");
  }
  if (project_end_date == "") {
    arr.push("project_end_date_err");
    arr.push("Project End Date Required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "new_project",
      data: {
        project_name: project_name,
        project_start_date: project_start_date,
        project_end_date: project_end_date,
        staff_id: staff_id,
        service_id: service_id,
        client_id: client_id,
        case_no: case_no,
        status: project_status,
        quotation_id: quotation_id,
      },
      success: function (res) {
        $("#NewProjectModal").modal("toggle");
        if (res.status == "success") {
          $("#NewProjectModal").modal("toggle");
          $(".project_name").val("");
          $(".project_start_date").val("");
          $(".project_end_date").val("");
          $(".staff_id").val("");
          $(".service_id").val("");
          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          fetch_projects_list();
        } else if (res.status == "error") {
          $("#NewProjectModal").modal("toggle");
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".update_project", function () {
  $("#NewProjectModal").modal("toggle");

  $(".project_btn").removeAttr("id");
  $(".modal_project_title").empty().html("Update Project");
  $(".project_btn").attr("id", "update_project");
  $(".project_btn_name").empty().html("Update");

  $("#projectid").val($(this).data("project_id"));
  $(".project_name").val($(this).data("project_name"));

  $(".project_start_date").val("");
  $(".project_end_date").val("");
  if (
    $(this).data("project_start_date") != "" ||
    $(this).data("project_end_date")
  ) {
    $(".project_start_date").val($(this).data("project_start_date"));
    $(".project_end_date").val($(this).data("project_end_date"));
  }

  // Set selected
  $(".staff_id").val($(this).data("project_staff_id"));
  $(".staff_id")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      multiple: true,
      dropdownParent: $("#NewProjectModal"),
    })
    .trigger("change");

  $(".service_id").val($(this).data("project_service_id"));
  $(".service_id")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
    })
    .trigger("change");
  $("#project_status").val($(this).data("project_status_id"));
  $("#project_status")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
    })
    .trigger("change");
});

$(document).on("click", "#update_project", function () {
  $(".valid_err").html("");
  var project_id = $("#projectid").val();
  var project_name = $(".project_name").val();
  var project_start_date = $(".project_start_date").val();
  var project_end_date = $(".project_end_date").val();
  var staff_id = $(".staff_id").val();
  var service_id = $(".service_id").val();
  var status = $("#project_status").val();
  if (staff_id.length == 0) {
    staff_id = null;
  }

  var arr = [];
  if (project_name == "") {
    arr.push("project_name_err");
    arr.push("Project Name required");
  }
  if (project_start_date == "") {
    arr.push("project_start_date_err");
    arr.push("Project Start Date Required");
  }
  if (project_end_date == "") {
    arr.push("project_end_date_err");
    arr.push("Project End Date Required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "update_project",
      data: {
        id: project_id,
        project_name: project_name,
        project_start_date: project_start_date,
        project_end_date: project_end_date,
        staff_id: staff_id,
        service_id: service_id,
        status: status,
      },
      success: function (res) {
        if (res.status == "success") {
          $("#NewProjectModal").modal("toggle");
          $("#projectid").val("");
          $(".project_name").val("");
          $(".project_start_date").val("");
          $(".project_end_date").val("");
          $(".staff_id").val("");
          $(".service_id").val("");
          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          fetch_projects_list();
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".delete_project", function () {
  var project_id = $(this).data("project_id");
  Swal.fire({
    title: "Are you sure?",
    text: "You want to delete this Project",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    confirmButtonClass: "btn btn-warning",
    cancelButtonClass: "btn btn-danger ml-1",
    buttonsStyling: false,
  }).then(function (result) {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "delete_project",
        data: {
          id: project_id,
        },
        success: function (res) {
          if (res.status == "success") {
            $("#alert").html(
              '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                res.msg +
                "</span></div></div>"
            );
            fetch_projects_list();
          } else if (res.status == "error") {
            $("#alert").html(
              '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                res.msg +
                "</span></div></div>"
            );
          }
        },
        error: function (data) {
          console.log(data);
        },
      });
    }
  });
});

$(document).on("click", ".new_modal_project", function () {
  $("#NewProjectModal").modal("toggle");
  $(".valid_err").html("");
  $(".project_btn").removeAttr("id");
  $(".modal_project_title").empty().html("Create Project");
  $(".project_btn").attr("id", "submit_project_btn");
  $(".project_btn_name").empty().html("Create");

  $("#projectid").val("");
  $(".project_name").val("");
  $(".project_start_date").val("");
  $(".project_end_date").val("");
  $(".staff_id")
    .val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
    })
    .trigger("change");
  $(".service_id")
    .val("")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
    })
    .trigger("change");
});

$(document).on("click", ".project_task", function (e) {
  $("a").click(function(event) {
    event.stopPropagation(); 
  });
  $(".new_task_modal12,.app-content-overlay").addClass("show");
  $(".select_proj_id_div").css("display", "none");
  $(".input_proj_id_div").css("display", "block");
  // $('#task_comment_div').css('display','none');
  $("#task_comment_div").css("display", "block");
  $(".task_btn").removeAttr("id");
  $(".new-task-title").empty().html("Update Task");
  $(".task_btn").attr("id", "update_task_btn");
  $(".task_btn_name").empty().html("Update");

  $("#project_id").val($(this).data("project_id"));
  $("#template_id").val($(this).data("template_id"));

  $(".new_task_editor > .ql-editor").html($(this).data("task_description"));
  $("#task_id").val($(this).data("task_id"));
  $(".task_title").val($(this).data("task_title"));
  $(".task_type").val($(this).data("task_type"));
  $(".task_priority").val($(this).data("task_priority"));
  if ($(this).data("task_status") != "") {
    $(".task_status").val($(this).data("task_status"));
  } else {
    $(".task_status").val("1");
  }

  $("#file_link").val($(this).data("file_link"));
  $(".div_file_link").hide();
  $(".div_file_upload").show();
  if ($(this).data("file_link") != "") {
    $(".div_file_link").show();
    $(".div_file_upload").hide();
    var fileName = /[^/]*$/.exec($(this).data("file_link"));
    var split = fileName[0].split(".");
    fileName = split[0];
    var extension = split[1];
    if (fileName.length > 10) {
      fileName = fileName.substring(0, 10);
    }
    $(".file_link")
      .attr("href", $(this).data("file_link"))
      .attr("download", fileName + "." + extension)
      .attr("target", "_blank")
      .text(fileName + "." + extension);
  }
  if ($(this).data("task_is_milestone") == "yes") {
    $(".task_is_milestone").prop("checked", true);
  } else {
    $(".task_is_milestone").prop("checked", false);
  }

  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });

  $(
    ".project_start_date,.project_end_date,.task_start_date,.task_end_date"
  ).val("");

  if ($(this).data("task_start_date") != "" || $(this).data("task_end_date")) {
    $(".task_start_date").val($(this).data("task_start_date"));
    $(".task_end_date").val($(this).data("task_end_date"));
  }
  console.log("abc=" + $(this).data("task_assignee"));
  // Set selected
  if ($(this).data("task_assignee") != "") {
    $(".task_assignee").val($(this).data("task_assignee")).trigger("change");
  } else {
    $(".task_assignee").val("");
  }

  if ($(this).data("office_id") != "") {
    $(".office_id").val($(this).data("office_id")).trigger("change");
  } else {
    $(".office_id").val("").select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Select Office'
    }).trigger("change");
  }

  // if ($(this).data("working_hr") != "") {
  //   $(".working_hr").val($(this).data("working_hr")).trigger("change");
  // } else {
  //   $(".working_hr").val("").select2({
  //     dropdownAutoWidth: true,
  //     width: "100%",
  //     placeholder:'Working Hour'
  //   }).trigger("change");
  // }
   $(".working_hr").val("").select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder:'Working Hour'
    }).trigger("change");

  $(".task_assignee")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder: "Select Assignee",
    })
    .trigger("change");
  if ($(e.target).hasClass("ignore-click") || $("a").hasClass("ignore-click")) {
    return false;
  }
});
//Project new Task other than new and inprogress alert msg
function projectAlertMsg(projectStatus,text_name) {
 var statusColor = '';
      if( projectStatus == 'New'){
        statusColor = '#bfd4fc';
      }else if(projectStatus == 'In Progress'){
        statusColor = '#e3b355';
      }else if(projectStatus == 'On Hold- Payment'){
        statusColor = '#63c4cb';
      }else if(projectStatus == 'On Hold- Documents'){
        statusColor = '#a5c8dd';
      }else if(projectStatus == 'Completed'){
        statusColor = '#5fb571';
      }else if(projectStatus == 'Cancelled'){
        statusColor = '#e59595';
      }else{
        statusColor = '#63c4cb';   
      }
  var alert_msg =
    'This project is <span style="color:' +
    statusColor +
    ';font-weight: bold;">' +
    projectStatus +
    "</span>.";
  alert_msg +=
    "<br>Please contact admin to change the status to create any "+text_name+" in this project.";
  Swal.fire({
    // title: "Info",
    html: alert_msg,
    icon: "info",
  });
}
$(document).on("click", ".new_task_alert", function () {
  var projectStatus = $(this).data("status");
  var text_name = $(this).data("text_name");
  // var statusColor = $(this).data("status_color");
  projectAlertMsg(projectStatus,text_name);
});
$(document).on("change", ".project_select", function () {
  var project_id = $(this).val();
  $('#save_task_submit_btn').attr('disabled',false);
  if(project_id != null || project_id != ''){

  $.ajax({
      type: "post",
      url: "getprojectstatus",
      data: {
        project_id: project_id
      },
      success: function (res) {
        if (res.status == "success") {
         var project_status = res.data.project_status;
         var project_status_id = res.data.project_status_id;
         console.log(project_status);
         console.log(project_status_id);
          if(!(project_status_id == 1 || project_status_id == 2)){
            projectAlertMsg(project_status,'task');
            $('#save_task_submit_btn').attr('disabled',true);
          }
        } else if (res.status == "error") {
          console.log(res);
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

//End Project functions

//Template Functions
//New Task Template Open form
$(document).on("click", ".new_task_Template_btn", function () {
  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });
  $(".div_file_link").hide();
  $(".select_proj_id_div").css("display", "none");
  $("#task_comment_div").css("display", "none");
  $(".input_proj_id_div").css("display", "block");
  $(
    ".project_start_date,.project_end_date,.task_start_date,.task_end_date"
  ).val("");
  $("#template_id").val($(this).data("main_template_id"));
  $("#task_id").val("");
  $(".valid_err").html("");
  $(".task_btn").removeAttr("id");
  $(".new-task-title").empty().html("New Task Template");
  $(".task_btn").attr("id", "submit_task_template_btn");
  $(".task_btn_name").empty().html("Save");
  $(".task_title").val("");
  // $('.ql-editor').html('');
  $(".new_task_editor > .ql-editor").html("");
  $(".task_type").val("");
  $(".task_priority").val("");
  $(".task_assignee").val("");
  $(".task_assignee")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder: "Select Assignee",
    })
    .trigger("change");
  $(".task_start_date").val("");
  $(".task_end_date").val("");
  $(".task_status").val();
  $(".task_is_milestone").prop("checked", false);
  $(".new_task_modal12,.app-content-overlay").addClass("show");
});

$(".new_task_cancel").click(function () {
  $(".todo-new-task-sidebar,.app-content-overlay").removeClass("show");
});

$(document).on("click", ".new_modal_template", function () {
  $("#NewTemplateModal").modal("toggle");
  $(".valid_err").html("");
  $(".template_btn").removeAttr("id");
  $(".modal_template_title").empty().html("Create Template");
  $(".template_btn").attr("id", "submit_template_btn");
  $(".template_btn_name").empty().html("Create");
  $("#form_template_status").hide();
  $("#templateid").val("");
  $(".template_name").val("");
  $(".template_description").val("");
});

$(document).on("click", "#submit_template_btn", function () {
  $(".valid_err").html("");
  var template_name = $(".template_name").val();
  var template_description = $(".template_description").val();

  var arr = [];
  if (template_name == "") {
    arr.push("template_name_err");
    arr.push("Template Name required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "add_template",
      data: {
        template_name: template_name,
        description: template_description,
      },
      success: function (res) {
        if (res.status == "success") {
          $("#NewTemplateModal").modal("toggle");
          $(".template_name").val("");
          fetch_template_list();
          fetch_template_task_list();

          console.log("add template");

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        } else if (res.status == "error") {
          $("#NewTemplateModal").modal("toggle");

          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", "#update_template", function () {
  $(".valid_err").html("");
  var template_id = $("#templateid").val();
  var template_name = $(".template_name").val();
  var template_description = $(".template_description").val();
  var template_status = $("#main_template_status").val();

  var arr = [];
  if (template_name == "") {
    arr.push("template_name_err");
    arr.push("Template Name required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "update_template",
      data: {
        id: template_id,
        template_name: template_name,
        description: template_description,
        status: template_status,
      },
      success: function (res) {
        if (res.status == "success") {
          $("#NewTemplateModal").modal("toggle");
          $("#templateid").val("");
          $(".template_name").val("");

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          location.reload();
        } else if (res.status == "error") {
          $("#NewTemplateModal").modal("toggle");

          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".delete_template", function () {
  var main_template_id = $(this).data("main_template_id");
  Swal.fire({
    title: "Are you sure?",
    text: "You want to delete this Template",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    confirmButtonClass: "btn btn-warning",
    cancelButtonClass: "btn btn-danger ml-1",
    buttonsStyling: false,
  }).then(function (result) {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "delete_template",
        data: {
          id: main_template_id,
        },
        success: function (res) {
          if (res.status == "success") {
            $("#alert").html(
              '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                res.msg +
                "</span></div></div>"
            );

            window.location.href = $("#base_url").val() + "/task";
          } else if (res.status == "error") {
            $("#alert").html(
              '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
                res.msg +
                "</span></div></div>"
            );
          }
        },
        error: function (data) {
          console.log(data);
        },
      });
    }
  });
});

$(document).on("click", "#update_template_task_btn", function () {
  $(".valid_err").html("");
  var id = $("#task_id").val();
  var main_template_id = $("#template_id").val();
  var task_title = $(".task_title").val();
  var task_description = $(".ql-editor").html();
  var task_type = $(".task_type").val();
  var task_priority = $(".task_priority").val();
  var task_assignee = $(".task_assignee").val();
  var task_start_date = $(".task_start_date").val();
  var task_end_date = $(".task_end_date").val();
  var task_status = $(".task_status").val();
  var task_is_milestone = $(".task_is_milestone:checked").val();
  var file_link = $("#file_link").val();
  var task_file = $(".task_file")[0].files[0];
  if (task_file == undefined) {
    task_file = "";
  }
  if (task_is_milestone == undefined) {
    task_is_milestone = "";
  }
  if (task_description == "<p><br></p>") {
    task_description = "";
  }
  var arr = [];
  if (task_title == "") {
    arr.push("task_title_err");
    arr.push("Title required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    var fd = new FormData();
    fd.append("id", id);
    fd.append("template_id", main_template_id);
    fd.append("title", task_title);
    fd.append("description", task_description);
    fd.append("priority", task_priority);
    fd.append("assignee", task_assignee);
    fd.append("task_date", task_date);
    fd.append("status", task_status);
    fd.append("type", task_type);
    fd.append("is_milestone", task_is_milestone);
    fd.append("file", task_file);
    fd.append("file_link", file_link);
    $.ajax({
      type: "post",
      url: "update_task_template",
      data: fd,
      contentType: false,
      cache: false,
      processData: false,
      success: function (res) {
        if (res.status == "success") {
          $(".todo-new-task-sidebar,.app-content-overlay").removeClass("show");
          $("#project_id").val("");
          $("#template_id").val("");
          $("#task_id").val("");
          $(".task_title").val("");
          $(".ql-editor").html("");
          $(".task_type").val("");
          $(".task_priority").val("");
          $(".task_assignee").val("");
          $(".task_date").val("");
          $(".task_status").val();
          $(".task_is_milestone").prop("checked", false);

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          location.reload();
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".update_main_template", function () {
  $("#NewTemplateModal").modal("toggle");
  $(".valid_err").html("");
  $(".template_btn").removeAttr("id");
  $(".modal_template_title").empty().html("Update Template");
  $(".template_btn").attr("id", "update_template");
  $(".template_btn_name").empty().html("Update");

  $("#form_template_status").show();
  $("#templateid").val($(this).data("main_template_id"));
  $(".template_name").val($(this).data("main_template_name"));
  $(".template_description").val($(this).data("main_template_description"));
  $("#main_template_status").val($(this).data("status"));
});

$(document).on("click", ".template_task", function () {
  $(".new_task_modal12,.app-content-overlay").addClass("show");
  $(".select_proj_id_div").css("display", "none");
  $("#task_comment_div").css("display", "none");
  $(".input_proj_id_div").css("display", "block");
  $(".task_btn").removeAttr("id");
  $(".new-task-title").empty().html("Update Template Task");
  $(".task_btn").attr("id", "update_template_task_btn");
  $(".task_btn_name").empty().html("Update");

  $("#task_id").val($(this).data("task_template_id"));
  $(".task_title").val($(this).data("task_title"));
  $("#template_id").val($(this).data("main_template_id"));
  $(".task_type").val($(this).data("task_type"));
  $(".task_priority").val($(this).data("task_priority"));
  if ($(this).data("task_status") != "") {
    $(".task_status").val($(this).data("task_status"));
  } else {
    $(".task_status").val("1");
  }

  $("#file_link").val($(this).data("file_link"));
  $(".div_file_link").hide();
  $(".div_file_upload").show();
  if ($(this).data("file_link") != "") {
    $(".div_file_link").show();
    $(".div_file_upload").hide();
    var fileName = /[^/]*$/.exec($(this).data("file_link"));
    var split = fileName[0].split(".");
    fileName = split[0];
    var extension = split[1];
    if (fileName.length > 10) {
      fileName = fileName.substring(0, 10);
    }
    $(".file_link")
      .attr("href", $(this).data("file_link"))
      .attr("download", fileName + "." + extension)
      .attr("target", "_blank")
      .text(fileName + "." + extension);
  }
  if ($(this).data("task_is_milestone") == "yes") {
    $(".task_is_milestone").prop("checked", true);
  } else {
    $(".task_is_milestone").prop("checked", false);
  }

  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });

  $(
    ".project_start_date,.project_end_date,.task_start_date,.task_end_date"
  ).val("");

  if ($(this).data("task_start_date") != "" || $(this).data("task_end_date")) {
    $(".task_start_date").val($(this).data("task_start_date"));
    $(".task_end_date").val($(this).data("task_end_date"));
  }
  var newTaskEditor = new Quill(".new_task_editor", {
    modules: {
      toolbar: ".new_task_quill_toolbar",
    },
    placeholder: "Add Description...",
    theme: "snow",
  });
  $(".new_task_editor > .ql-editor").html("");
  if ($(this).data("task_description") != "") {
    $(".new_task_editor > .ql-editor").html($(this).data("task_description"));
  }

  // if ($(this).data('task_description') != '') {
  //   $('.ql-editor').html($(this).data('task_description'));
  // }
  // Set selected
  console.log(12345);
  if ($(this).data("task_assignee") != "") {
    $(".task_assignee").val($(this).data("task_assignee"));
  } else {
    $(".task_assignee").val("");
  }
  $(".task_assignee")
    .select2({
      dropdownAutoWidth: true,
      width: "100%",
      placeholder: "Select Assignee",
    })
    .trigger("change");
  return false;
});

// Duplicate template task

$(document).on("click", ".create_task_from_template", function () {
  $(".valid_err").html("");
  $("#TemplateToTaskModal").modal("toggle");
  $(".select_proj_id_div").css("display", "none");
  $("#task_comment_div").css("display", "none");
  $(".input_proj_id_div").css("display", "block");
  $("#modal_project_id").val($(this).data("project_id"));
  $(".main_template").removeClass("main_template_selected");
});

$(document).on("click", ".main_template", function () {
  $("#modal_main_template_id").val("");
  $(".main_template").removeClass("main_template_selected");
  $(this).addClass("main_template_selected");
  $("#modal_main_template_id").val($(this).data("main_template_id"));
});

$(document).on("click", "#submit_create_template_task", function () {
  $(".modal_err").html("");
  var modal_project_id = $("#modal_project_id").val();
  var modal_main_template_id = $("#modal_main_template_id").val();
  // modal_err
  if (modal_main_template_id == "") {
    var error_msg = "Please Select Template";
    $(".modal_err").html(
      '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
        error_msg +
        "</span></div></div>"
    );
  } else {
    $.ajax({
      type: "post",
      url: "duplicate_template",
      data: {
        project_id: modal_project_id,
        main_template_id: modal_main_template_id,
      },
      success: function (res) {
        if (res.status == "success") {
          $("#TemplateToTaskModal").modal("toggle");
          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        } else if (res.status == "error") {
          // $('#TemplateToTaskModal').modal('toggle');
          $(".modal_err").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});
// End Duplicate
//End Template Functions

//Subtask
$(document).on("click", ".add_subtask_btn", function (e) {
  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });
  $(".div_subtask_file_link").hide();
  $(".project_start_date,.project_end_date,.subtask_date").val("");
  $("#sub_project_id").val($(this).data("project_id"));
  $("#_task_id").val($(this).data("task_id"));
  $("#sub_template_id").val($(this).data("template_id"));
  $("#taskTitle").empty().html($(this).data("task_title"));
  $(".valid_err").html("");
  $(".subtask_btn").removeAttr("id");
  $(".sub-task-title").empty().html("Create Sub Task");
  $(".subtask_btn").attr("id", "save_subtask_submit_btn");
  $(".subtask_btn_name").empty().html("Save");
  $(".subtask_title").val("");
  $(".subtask_editor > .ql-editor").html("");
  $(".subtask_type").val("");
  $(".subtask_priority").val("");
  $(".subtask_assignee").select2().val("").trigger("change");
  $(".subtask_date").val("");
  $(".subtask_status").val("");
  $(".subtask_is_milestone").prop("checked", false);
  $(".add_subtask_sidebar,.app-content-overlay").addClass("show");
});

//create subtask save data
$(document).on("click", "#save_subtask_submit_btn", function () {
  $(".valid_err").html("");
  var project_id = $("#sub_project_id").val();
  var _task_id = $("#_task_id").val();
  var template_id = $("#sub_template_id").val();
  var task_title = $(".subtask_title").val();
  var task_description = $(".subtask_editor > .ql-editor").html();
  var task_type = $(".subtask_type").val();
  var task_priority = $(".subtask_priority").val();
  var task_assignee = $(".subtask_assignee").val();
  var task_date = $(".subtask_date").val();
  var task_status = $(".subtask_status").val();
  var task_is_milestone = $(".subtask_is_milestone:checked").val();
  var task_file = $(".subtask_file")[0].files[0];

  if (task_is_milestone == undefined) {
    task_is_milestone = "";
  }
  if (task_file == undefined) {
    task_file = "";
  }
  if (task_description == "<p><br></p>") {
    task_description = "";
  }
  var fdata = new FormData();
  fdata.append("project_id", project_id);
  fdata.append("task_id", _task_id);
  fdata.append("template_id", template_id);
  fdata.append("title", task_title);
  fdata.append("description", task_description);
  fdata.append("type", task_type);
  fdata.append("priority", task_priority);
  fdata.append("assignee", task_assignee);
  fdata.append("task_date", task_date);
  fdata.append("status", task_status);
  fdata.append("is_milestone", task_is_milestone);
  fdata.append("file", task_file);

  var arr = [];
  if (task_title == "") {
    arr.push("subtask_title_err");
    arr.push("Title required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    $.ajax({
      type: "post",
      url: "add_subtask",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (data) {
        console.log("save successfully");
        var res = JSON.parse(data);
        console.log(res);

        if (res.status == "success") {
          $(".add_subtask_sidebar,.app-content-overlay").removeClass("show");
          $("#sub_project_id").val("");
          $("#_task_id").val("");
          $("#sub_template_id").val("");
          $(".subtask_title").val("");
          $(".subtask_editor > .ql-editor").html("");
          $(".subtask_type").val("");
          $(".subtask_priority").val("");
          $(".subtask_assignee").val("");
          $(".subtask_date").val("");
          $(".subtask_status").val("");
          $(".subtask_is_milestone").prop("checked", false);
          $(".subtask_file").val("");

          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          fetch_task_list();
          fetch_staff_wise_task_list();
          location.reload();
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(document).on("click", ".subtask_update_click", function (e) {
  $(".add_subtask_sidebar,.app-content-overlay").addClass("show");
  $(".subtask_btn").removeAttr("id");
  $(".sub-task-title").empty().html("Update Sub Task");
  $(".subtask_btn").attr("id", "update_subtask_btn");
  $(".subtask_btn_name").empty().html("Update");

  $("#subtask_id").val($(this).data("id"));
  $("#taskTitle").html($(this).data("task_title"));
  $("#sub_project_id").val($(this).data("project_id"));
  subtask_id;
  $("#sub_template_id").val($(this).data("template_id"));
  $("#_task_id").val($(this).data("task_id"));
  $(".subtask_title").val($(this).data("title"));
  $(".subtask_type").val($(this).data("type"));
  $(".subtask_priority").val($(this).data("priority"));
  $(".subtask_status").val($(this).data("status"));

  $("#subtask_file_link").val($(this).data("subtask_file_link"));
  $(".div_subtask_file_link").hide();
  $(".div_subtask_file_upload").show();
  if ($(this).data("subtask_file_link") != "") {
    $(".div_subtask_file_link").show();
    $(".div_subtask_file_upload").hide();
    var fileName1 = /[^/]*$/.exec($(this).data("subtask_file_link"));
    var split1 = fileName1[0].split(".");
    fileName1 = split1[0];
    var extension1 = split1[1];
    if (fileName1.length > 10) {
      fileName1 = fileName1.substring(0, 10);
    }
    $(".subtask_file_link")
      .attr("href", $(this).data("subtask_file_link"))
      .attr("download", fileName1 + "." + extension1)
      .attr("target", "_blank")
      .text(fileName1 + "." + extension1);
  }

  if ($(this).data("subtask_is_milestone") == "yes") {
    $(".subtask_is_milestone").prop("checked", true);
  } else {
    $(".subtask_is_milestone").prop("checked", false);
  }

  $(".autoapply").daterangepicker({
    autoApply: true,
    locale: {
      format: "DD/MM/YYYY",
    },
  });

  $(".project_start_date,.project_end_date,.subtask_date").val("");

  if ($(this).data("task_start_date") != "" || $(this).data("task_end_date")) {
    $(".subtask_date").val(
      $(this).data("task_start_date") + " - " + $(this).data("task_end_date")
    );

    $(".autoapply").daterangepicker(
      {
        showDropdowns: true,
        autoApply: true,
        locale: {
          format: "DD/MM/YYYY",
        },
        autoclose: true,
        alwaysShowCalendars: true,
        startDate: $(this).data("task_start_date"),
        endDate: $(this).data("task_end_date"),
      },
      function (start, end) {
        $("#start_date_input").val(start.format("DD/MM/YYYY"));
        $("#end_date_input").val(end.format("DD/MM/YYYY"));
      }
    );
  }
  var newTaskEditor = new Quill(".subtask_editor", {
    modules: {
      toolbar: ".subtask_quill_toolbar",
    },
    placeholder: "Add Description...",
    theme: "snow",
  });
  $(".subtask_editor > .ql-editor").html("");
  if ($(this).data("task_description") != "") {
    $(".subtask_editor > .ql-editor").html($(this).data("task_description"));
  }
  // Set selected
  $(".subtask_assignee").val($(this).data("assignee"));
  $(".subtask_assignee").select2().trigger("change");
});

$(document).on("click", "#update_subtask_btn", function () {
  $(".valid_err").html("");
  var id = $("#subtask_id").val();
  var task_id = $("#_task_id").val();
  var project_id = $("#sub_project_id").val();
  var template_id = $("#sub_template_id").val();
  var title = $(".subtask_title").val();
  var description = $(".subtask_editor > .ql-editor").html();
  var type = $(".subtask_type").val();
  var priority = $(".subtask_priority").val();
  var assignee = $(".subtask_assignee").val();
  var subtask_date = $(".subtask_date").val();
  var status = $(".subtask_status").val();
  var is_milestone = $(".subtask_is_milestone:checked").val();
  var subtask_file_link = $("#subtask_file_link").val();
  var subtask_task_file = $(".subtask_file")[0].files[0];
  if (subtask_task_file == undefined) {
    subtask_task_file = "";
  }
  if (is_milestone == undefined) {
    is_milestone = "";
  }
  if (description == "<p><br></p>") {
    description = "";
  }
  var arr = [];
  if (title == "") {
    arr.push("task_title_err");
    arr.push("Title required");
  }
  if (arr != "") {
    for (var i = 0; i < arr.length; i++) {
      var j = i + 1;
      $("." + arr[i])
        .html(arr[j])
        .css("color", "red");
      i = j;
    }
  } else {
    var fd = new FormData();
    fd.append("id", id);
    fd.append("project_id", project_id);
    fd.append("task_id", task_id);
    fd.append("template_id", template_id);
    fd.append("title", title);
    fd.append("description", description);
    fd.append("type", type);
    fd.append("priority", priority);
    fd.append("assignee", assignee);
    fd.append("task_date", subtask_date);
    fd.append("status", status);
    fd.append("is_milestone", is_milestone);
    fd.append("file", subtask_task_file);
    fd.append("file_link", subtask_file_link);

    $.ajax({
      type: "post",
      url: "update_subtask",
      data: fd,
      contentType: false,
      cache: false,
      processData: false,
      success: function (res) {
        console.log("update successfully");
        if (res.status == "success") {
          $(".add_subtask_sidebar,.app-content-overlay").removeClass("show");

          $("#subtask_id").val("");
          $("#_task_id").val("");
          $("#sub_project_id").val("");
          $("#sub_template_id").val("");
          $(".subtask_title").val("");
          $(".subtask_editor > .ql-editor").html("");
          $(".subtask_type").val("");
          $(".subtask_priority").val("");
          $(".subtask_assignee").val("");
          $(".subtask_date").val("");
          $(".subtask_status").val("");
          $(".subtask_is_milestone").prop("checked", false);

          fetch_task_list();
          fetch_staff_wise_task_list;
          $("#alert").html(
            '<div class="alert bg-rgba-success alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
          location.reload();
        } else if (res.status == "error") {
          $("#alert").html(
            '<div class="alert bg-rgba-danger alert-dismissible mx-5" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><div class="d-flex align-items-center"><i class="bx bx-like"></i><span>' +
              res.msg +
              "</span></div></div>"
          );
        }
      },
      error: function (data) {
        console.log(data);
      },
    });
  }
});

$(".subtask_cancel").click(function () {
  $(".add_subtask_sidebar,.app-content-overlay").removeClass("show");
});
//End Subtask

function fetch_projects_list() {
  $.ajax({
    type: "get",
    url: "projects_table",
    success: function (res) {
      $(".project_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}

function fetch_task_list(search_task = "") {
  $.ajax({
    type: "post",
    url: "get_task_list",
    data: {
      search_task: search_task,
    },
    success: function (res) {
      $(".task_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}
function fetch_staff_wise_task_list(search_task = "") {
  $.ajax({
    type: "post",
    url: "get_staff_wise_task",
    data: {
      search_task: search_task,
    },
    success: function (res) {
      $(".staff_task_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}
function fetch_hearing_task(hearing_filter_from_date,hearing_filter_to_date,task_filter_status) {
  $.ajaxSetup({
    headers: {
      "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
    },
  });

if(hearing_filter_from_date==undefined)
{
    hearing_filter_from_date='';
}
if(hearing_filter_to_date==undefined)
{
    hearing_filter_to_date='';
}
  if ((hearing_filter_from_date !== "" && hearing_filter_to_date !== "") ) {
        var startDateParts = hearing_filter_from_date.split("/");
         var endDateParts = hearing_filter_to_date.split("/");

  var startDateObj = new Date(
    startDateParts[2],
    startDateParts[1] - 1,
    startDateParts[0]
  );
  var endDateObj = new Date(
    endDateParts[2],
    endDateParts[1] - 1,
    endDateParts[0]
  );
      if(endDateObj < startDateObj)
      {
           alert("please select To Date greater than or equal to From Date");
            return false;
      }
   
  }

  $.ajax({
    type: "post",
    url: "get_hearing_task",
    data: {
      task_filter_status: task_filter_status,
      hearing_filter_from_date: hearing_filter_from_date,
      hearing_filter_to_date: hearing_filter_to_date,
    },
    success: function (res) {
      $("#hearing_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}
function fetch_client_project_list() {
  $.ajax({
    type: "post",
    url: "client_project_list",
    data: {},
    success: function (res) {
      $(".client_project_list").empty().html(res);

      // Client Project menu active
      var url2 = window.location.href.split("/");
      var client_link = url2[url2.length - 1];
      // console.log(client_link.split('-')[0]);
      //url match projects_task-12
      if ("projects_task" == client_link.split("-")[0]) {
        $(".client_project_link").each(function (i) {
          var href_1 = $(this).attr("href");
          // console.log(href_1);
          if (href_1.indexOf(client_link) !== -1) {
            $(".div_project" + $(this).data("client_id")).addClass("show");
            $(this).addClass("template_active");
          }
        });
      }
      //End Client Project menu active
    },
    error: function (data) {
      console.log(data);
    },
  });
}

function fetch_template_task_list() {
  $.ajax({
    type: "post",
    url: "template_task_list",
    data: {},
    success: function (res) {
      $(".template_task_list").empty().html(res);

      // template menu active show logic
      var url1 = window.location.href.split("/");
      var template_link = url1[url1.length - 1];
      if ("template_task" == template_link.split("-")[0]) {
        $("#list_template a").each(function (i) {
          var href = $(this).attr("href");
          if (href.indexOf(template_link) !== -1) {
            // console.log(href);
            $(this).addClass("template_active");
          }
        });
      }
      //End template menu active show logic
    },
    error: function (data) {
      console.log(data);
    },
  });
}

function search_task(value) {
  fetch_task_list(value);
}

function assignee_list() {
  $.ajax({
    type: "get",
    url: "assignee_list",
    data: {},
    success: function (res) {
      console.log(res);
      if (res.status == "success") {
        var innerhtml = "";
        for (let i = 0; i < res.data.length; i++) {
          if (res.role == 1) {
            innerhtml +=
              '<option value = "' +
              res.data[i].sid +
              '">' +
              res.data[i].name +
              " </option>";
          } else {
            innerhtml +=
              '<option value = "' +
              res.data[i].sid +
              '" selected>' +
              res.data[i].name +
              " </option>";
          }

          $(".staff_id").empty().append(innerhtml);
          $(".task_assignee").empty().append(innerhtml);
        }
      }
    },

    error: function (data) {
      console.log(data);
    },
  });
}
$(document).on("click", ".file_delete", function () {
  $("#file_link").val("");
  $(".div_file_link").hide();
  $(".div_file_upload").show();
});
$(document).on("click", ".subtask_file_delete", function () {
  $("#subtaskfile_link").val("");
  $(".div_subtask_file_link").hide();
  $(".div_subtask_file_upload").show();
});
function fetch_template_list() {
  $.ajax({
    type: "get",
    url: "template_table",
    success: function (res) {
      $(".template_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}

$.ajax({
  type: "get",
  url: "assignee_list",
  data: {},
  success: function (res) {
    console.log(res);
    if (res.status == "success") {
      var innerhtml = "";
      for (let i = 0; i < res.data.length; i++) {
        if (res.role == 1) {
          innerhtml +=
            '<option value = "' +
            res.data[i].sid +
            '">' +
            res.data[i].name +
            " </option>";
        } else {
          innerhtml +=
            '<option value = "' +
            res.data[i].sid +
            '" selected>' +
            res.data[i].name +
            " </option>";
        }

        $(".task_assignee").empty().append(innerhtml);
      }
    }
  },
  error: function (data) {
    console.log(data);
  },
});

$(document).on("click", ".file_delete", function () {
  $("#file_link").val("");
  $(".div_file_link").hide();
  $(".div_file_upload").show();
});
$(document).on("click", ".subtask_file_delete", function () {
  $("#subtaskfile_link").val("");
  $(".div_subtask_file_link").hide();
  $(".div_subtask_file_upload").show();
});

function fetch_template_list() {
  $.ajax({
    type: "get",
    url: "template_table",
    success: function (res) {
      $(".template_list").empty().html(res);
    },
    error: function (data) {
      console.log(data);
    },
  });
}
 function get_task_comment(task_id) {
        $.ajax({
          type: "post",
          url: "get_task_comment",
          data: {
            task_id: task_id,
          },
          success: function (res) {
            
           
             data=res.data;
             console.log(data);
             var out='';
             $.each(data, function(index) {
           
              out+='<div class="ModalCommentBox"><div class="row"><div class="col-sm-1 CommentIcon"><i class="bx bx-comment"></i></div><div class="col-sm-8 CommentTital"><h4>'+data[index].staff_name+'</h4></div><div class="col-sm-3 CommentDate"><p>'+data[index].timeDifference+'</p></div></div><div class="row CommentAdjust"><div class="col-sm-1"></div><div class="col-sm-9 CMContent"><p>'+data[index].comment+'</p></div></div></div>';
             });
            $('.CommentDiv').empty().html(out);
          },
          error: function (data) {
            console.log(data);
          },
        });
      }